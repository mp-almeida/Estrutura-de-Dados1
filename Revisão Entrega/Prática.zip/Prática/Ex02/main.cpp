#include <iostream>

using namespace std;
//Dado o seguinte trecho de c�digo, complete-o e exiba o valor
//e o endere�o das vari�veis x e y (diretamente e via ponteiro),
//e o valor e endere�o dos ponteiros ptr1 e ptr2. O objetivo �
//verificar a sa�da para os valores de y:
//
//int x=3, y=9, *ptrx, *ptry;
//
//ptrx = &x;
//
//ptry = nullptr;
//
//// ... complete o c�digo para exibir os valores e endere�os de x,y, prtx, ptry.
//
//ptry=&y;
//
//*ptry=5;
//
//       // ... exiba os valores e endere�os novamente
int main()
{
    int x=3, y=9, *ptrx, *ptry;

    ptrx = &x;

    ptry = nullptr; // n�o aponta para valor v�lido


// ... complete o c�digo para exibir os valores e endere�os de x,y, prtx, ptry.
    cout << "Valor de X: " << x << endl;
    cout << "Valor de y: " << y << endl;
    cout << "Valor de x (ponteiro): " << *ptrx << endl;
    cout << "Valor de y (ponteiro): " << *ptry << endl;

    ptry = &y;
    *ptry = 5;

    cout << "Valor do ponteiro X: " << *ptrx << endl;
    cout << "Valor do ponteiro Y: " << *ptry << endl;
    cout << "Valor do endere�o do ponteiro X: " << &ptrx << endl;
    cout << "Valor do endere�o do ponteiro y: " << &ptry << endl;
    return 0;
}
